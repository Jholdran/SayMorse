// ==========================================================
//  SAYMORSE - script.js
//  Voz/Texto ⇄ Morse, con sonido, luz, tono, diccionario,
//  modo noche y dos idiomas (Español Latinoamérica / English)
// ==========================================================

// ---------- TEXTOS EN CADA IDIOMA ----------
// Para agregar o cambiar un texto, edítalo aquí.
const TEXTOS = {
  es: {
    titulo: "SayMorse — Tu voz en puntos y rayas",
    descripcion: "SayMorse: habla o escribe y convierte tu mensaje a código Morse, o traduce Morse a texto. Con sonido y luz.",
    subtitulo: "Tu voz en puntos y rayas",
    pie: "SayMorse · Tu voz en puntos y rayas",

    // Tema (día / noche)
    temaNoche: "Noche",
    temaDia: "Día",
    ariaIrNoche: "Cambiar a modo noche",
    ariaIrDia: "Cambiar a modo día",

    // Botón de idioma
    botonIdioma: "EN",
    ariaIdioma: "Switch to English",

    // Entrada
    tuMensaje: "Tu mensaje",
    tuMorse: "Tu Morse",
    borrarTodo: "Borrar todo",
    placeholderTexto: "Habla con el micrófono o escribe aquí tu mensaje...",
    placeholderMorse: "Escribe puntos y rayas. Ej: .... --- .-.. .-  /  -- ..- -. -.. ---",
    ayudaEntrada: "Usa puntos (.), rayas (-), un espacio entre letras y una barra / entre palabras.",

    // Voz
    dictar: "🎤 Dictar",
    detener: "⏹ Detener",
    idioma: "Idioma",
    estado_apagado: "Micrófono apagado",
    estado_escuchando: "Escuchando...",
    estado_permiso: "Permiso de micrófono denegado.",
    estado_sinmicro: "No se encontró ningún micrófono.",
    estado_red: "Error de red. Revisa tu conexión.",
    estado_sinsoporte: "Dictado no disponible aquí (usa Chrome o Edge). Puedes escribir.",
    optEs419: "Español (Latinoamérica)",
    optEsMX: "Español (México)",
    optEsCO: "Español (Colombia)",
    optEsAR: "Español (Argentina)",
    optEsES: "Español (España)",
    optEnUS: "Inglés (EE. UU.)",
    optEnGB: "Inglés (Reino Unido)",

    // Teclado Morse
    punto: "punto",
    raya: "raya",
    letra: "letra",
    palabra: "palabra",
    borrar: "borrar",
    ariaPunto: "Punto",
    ariaRaya: "Raya",
    ariaLetra: "Espacio entre letras",
    ariaPalabra: "Separador de palabras",
    ariaBorrar: "Borrar un carácter",

    // Invertir
    chipTexto: "Texto",
    chipMorse: "Morse",
    invertir: "Invertir dirección",
    invertirAria: "Invertir dirección de la traducción",

    // Salida
    codigoMorse: "Código Morse",
    textoTraducido: "Texto traducido",
    vacioMorse: "El Morse aparecerá aquí...",
    vacioTexto: "El texto aparecerá aquí...",
    luzTitulo: "Luz del telégrafo",
    transmitir: "▶ Transmitir",
    parar: "⏹ Parar",
    copiarMorse: "📋 Copiar Morse",
    copiarTexto: "📋 Copiar texto",
    copiado: "✅ ¡Copiado!",
    noCopio: "No se pudo copiar",

    // Ajustes
    ajustesSonido: "Ajustes de sonido",
    velocidad: "⏱ Velocidad:",
    ppm: "ppm",
    tono: "🎵 Tono:",
    grave: "Grave",
    agudo: "Agudo",
    sonidoActivado: "🔊 Sonido activado",

    // Diccionario
    diccionario: "Diccionario Morse",
    tocaLetra: "Toca una letra o un número para oírlo.",
    letras: "Letras",
    numeros: "Números",
    nota: "Un punto dura una unidad y una raya, tres. Entre las señales de una misma letra hay una unidad de silencio, tres entre letras y siete entre palabras. Las tildes se transmiten sin acento y la Ñ tiene su propio código (--.--)."
  },

  en: {
    titulo: "SayMorse — Your voice in dots and dashes",
    descripcion: "SayMorse: speak or type your message and convert it to Morse code, or translate Morse back to text. With sound and light.",
    subtitulo: "Your voice in dots and dashes",
    pie: "SayMorse · Your voice in dots and dashes",

    temaNoche: "Night",
    temaDia: "Day",
    ariaIrNoche: "Switch to night mode",
    ariaIrDia: "Switch to day mode",

    botonIdioma: "ES",
    ariaIdioma: "Cambiar a español",

    tuMensaje: "Your message",
    tuMorse: "Your Morse",
    borrarTodo: "Clear all",
    placeholderTexto: "Speak into the microphone or type your message here...",
    placeholderMorse: "Type dots and dashes. E.g.: .... . .-.. .-.. ---  /  .-- --- .-. .-.. -..",
    ayudaEntrada: "Use dots (.), dashes (-), a space between letters and a slash / between words.",

    dictar: "🎤 Dictate",
    detener: "⏹ Stop",
    idioma: "Language",
    estado_apagado: "Microphone off",
    estado_escuchando: "Listening...",
    estado_permiso: "Microphone permission denied.",
    estado_sinmicro: "No microphone found.",
    estado_red: "Network error. Check your connection.",
    estado_sinsoporte: "Dictation isn't available here (use Chrome or Edge). You can still type.",
    optEs419: "Spanish (Latin America)",
    optEsMX: "Spanish (Mexico)",
    optEsCO: "Spanish (Colombia)",
    optEsAR: "Spanish (Argentina)",
    optEsES: "Spanish (Spain)",
    optEnUS: "English (US)",
    optEnGB: "English (UK)",

    punto: "dot",
    raya: "dash",
    letra: "letter",
    palabra: "word",
    borrar: "delete",
    ariaPunto: "Dot",
    ariaRaya: "Dash",
    ariaLetra: "Space between letters",
    ariaPalabra: "Word separator",
    ariaBorrar: "Delete one character",

    chipTexto: "Text",
    chipMorse: "Morse",
    invertir: "Swap direction",
    invertirAria: "Swap translation direction",

    codigoMorse: "Morse code",
    textoTraducido: "Translated text",
    vacioMorse: "The Morse will appear here...",
    vacioTexto: "The text will appear here...",
    luzTitulo: "Telegraph light",
    transmitir: "▶ Transmit",
    parar: "⏹ Stop",
    copiarMorse: "📋 Copy Morse",
    copiarTexto: "📋 Copy text",
    copiado: "✅ Copied!",
    noCopio: "Couldn't copy",

    ajustesSonido: "Sound settings",
    velocidad: "⏱ Speed:",
    ppm: "wpm",
    tono: "🎵 Pitch:",
    grave: "Low",
    agudo: "High",
    sonidoActivado: "🔊 Sound on",

    diccionario: "Morse dictionary",
    tocaLetra: "Tap a letter or a number to hear it.",
    letras: "Letters",
    numeros: "Numbers",
    nota: "A dot lasts one unit and a dash lasts three. Within a letter there is one unit of silence between signals, three between letters and seven between words. Accents are sent without the accent mark, and Ñ has its own code (--.--)."
  }
};

// Idioma de la página: "es" (principal) o "en"
let idiomaPagina = "es";

// Devuelve el texto en el idioma actual
function t(clave) {
  return TEXTOS[idiomaPagina][clave] || TEXTOS.es[clave] || clave;
}

// ---------- DICCIONARIO MORSE ----------
const MORSE = {
  // Letras
  "A": ".-",    "B": "-...",  "C": "-.-.",  "D": "-..",   "E": ".",
  "F": "..-.",  "G": "--.",   "H": "....",  "I": "..",    "J": ".---",
  "K": "-.-",   "L": ".-..",  "M": "--",    "N": "-.",    "Ñ": "--.--",
  "O": "---",   "P": ".--.",  "Q": "--.-",  "R": ".-.",   "S": "...",
  "T": "-",     "U": "..-",   "V": "...-",  "W": ".--",   "X": "-..-",
  "Y": "-.--",  "Z": "--..",

  // Números
  "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-",
  "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",

  // Signos de puntuación
  ".": ".-.-.-", ",": "--..--", "?": "..--..", "!": "-.-.--",
  "'": ".----.", "\"": ".-..-.", "(": "-.--.",  ")": "-.--.-",
  ":": "---...", ";": "-.-.-.", "=": "-...-",  "+": ".-.-.",
  "-": "-....-", "@": ".--.-."
};

// Diccionario al revés: de ".-" a "A"
const INVERSO = {};
for (const caracter in MORSE) {
  INVERSO[MORSE[caracter]] = caracter;
}

// ---------- REFERENCIAS A LOS ELEMENTOS DE LA PÁGINA ----------
const boton = document.getElementById("btn-micro");
const indicador = document.getElementById("indicador");
const textoEstado = document.getElementById("texto-estado");
const selectIdioma = document.getElementById("idioma");
const panelVoz = document.getElementById("panel-voz");

const mensaje = document.getElementById("mensaje");
const btnBorrar = document.getElementById("btn-borrar");
const tituloEntrada = document.getElementById("titulo-entrada");
const ayudaEntrada = document.getElementById("ayuda-entrada");

const panelTeclado = document.getElementById("panel-teclado");
const btnPunto = document.getElementById("btn-punto");
const btnRaya = document.getElementById("btn-raya");
const btnLetra = document.getElementById("btn-letra");
const btnPalabra = document.getElementById("btn-palabra");
const btnRetroceso = document.getElementById("btn-retroceso");

const btnInvertir = document.getElementById("btn-invertir");
const chipOrigen = document.getElementById("chip-origen");
const chipDestino = document.getElementById("chip-destino");

const tituloSalida = document.getElementById("titulo-salida");
const resultado = document.getElementById("resultado");
const luz = document.getElementById("luz-morse");
const btnTransmitir = document.getElementById("btn-transmitir");
const btnCopiar = document.getElementById("btn-copiar");

const chkSonido = document.getElementById("chk-sonido");
const sliderVelocidad = document.getElementById("velocidad");
const valorVelocidad = document.getElementById("valor-velocidad");
const sliderTono = document.getElementById("tono");
const valorTono = document.getElementById("valor-tono");

const btnTema = document.getElementById("btn-tema");
const btnIdioma = document.getElementById("btn-idioma");
const metaTema = document.querySelector('meta[name="theme-color"]');
const metaDescripcion = document.querySelector('meta[name="description"]');

// ---------- ESTADO ----------
// "texto" = Texto → Morse   |   "morse" = Morse → Texto
let modo = "texto";

// Función que apaga el dictado (la define iniciarApp más abajo)
let detenerDictado = null;

// Estado del micrófono: apagado | escuchando | permiso | sinmicro | red | sinsoporte
let estadoMicro = "apagado";

// Pinta el botón y el mensaje del micrófono en el idioma actual
function refrescarMicro() {
  const escuchando = estadoMicro === "escuchando";
  boton.classList.toggle("activo", escuchando);
  indicador.classList.toggle("escuchando", escuchando);
  boton.textContent = escuchando ? t("detener") : t("dictar");
  textoEstado.textContent = t("estado_" + estadoMicro);
}

// ---------- MODO DÍA / NOCHE ----------
function temaActual() {
  return document.documentElement.getAttribute("data-tema") === "noche" ? "noche" : "dia";
}

// Aplica el tema; si "guardar" es true, recuerda la elección
function aplicarTema(tema, guardar) {
  const esNoche = tema === "noche";

  document.documentElement.setAttribute("data-tema", tema);

  // El botón muestra a qué modo se puede cambiar
  btnTema.querySelector(".tema-icono").textContent = esNoche ? "☀️" : "🌙";
  btnTema.querySelector(".tema-texto").textContent = esNoche ? t("temaDia") : t("temaNoche");
  btnTema.setAttribute(
    "aria-label",
    esNoche ? t("ariaIrDia") : t("ariaIrNoche")
  );

  // Color de la barra del navegador en el celular
  if (metaTema) {
    metaTema.setAttribute("content", esNoche ? "#0d1526" : "#f7f0e1");
  }

  if (guardar) {
    try {
      localStorage.setItem("saymorse-tema", tema);
    } catch (error) {
      // si el navegador no deja guardar, no pasa nada
    }
  }
}

btnTema.addEventListener("click", () => {
  aplicarTema(temaActual() === "noche" ? "dia" : "noche", true);
});

// ---------- IDIOMA DE LA PÁGINA (ES / EN) ----------
function aplicarIdioma(idioma, guardar) {
  idiomaPagina = idioma === "en" ? "en" : "es";

  document.documentElement.lang = idiomaPagina === "en" ? "en" : "es-419";
  document.title = t("titulo");
  if (metaDescripcion) metaDescripcion.setAttribute("content", t("descripcion"));

  // Textos fijos marcados en el HTML
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    el.title = t(el.dataset.i18nTitle);
  });
  document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
    el.setAttribute("aria-label", t(el.dataset.i18nAria));
  });

  // Botón de idioma: muestra a cuál idioma se puede cambiar
  btnIdioma.querySelector(".idioma-texto").textContent = t("botonIdioma");
  btnIdioma.setAttribute("aria-label", t("ariaIdioma"));
  btnIdioma.title = t("ariaIdioma");

  // El idioma de dictado acompaña al de la página
  const actual = selectIdioma.value;
  let nuevo = actual;
  if (idiomaPagina === "en" && actual.startsWith("es")) nuevo = "en-US";
  if (idiomaPagina === "es" && actual.startsWith("en")) nuevo = "es-419";
  if (nuevo !== actual) {
    selectIdioma.value = nuevo;
    selectIdioma.dispatchEvent(new Event("change"));
  }

  // Textos que cambian según el estado de la app
  aplicarTema(temaActual(), false);
  refrescarMicro();
  etiquetaTransmitir(reproduciendo);
  aplicarModo();

  if (guardar) {
    try {
      localStorage.setItem("saymorse-idioma", idiomaPagina);
    } catch (error) {
      // si el navegador no deja guardar, no pasa nada
    }
  }
}

btnIdioma.addEventListener("click", () => {
  aplicarIdioma(idiomaPagina === "es" ? "en" : "es", true);
});

// Idioma guardado (si no hay ninguno, la página arranca en español)
function idiomaInicial() {
  try {
    const guardado = localStorage.getItem("saymorse-idioma");
    if (guardado === "en" || guardado === "es") return guardado;
  } catch (error) {
    // sin almacenamiento: usamos español
  }
  return "es";
}

// ---------- TRADUCCIÓN: TEXTO → MORSE ----------

// Pasa a mayúsculas y quita las tildes (á → A), pero conserva la Ñ
function limpiarTexto(texto) {
  return texto
    .toUpperCase()
    .replace(/Ñ/g, "#")                 // protegemos la Ñ temporalmente
    .normalize("NFD")                   // separa las letras de sus tildes
    .replace(/[\u0300-\u036f]/g, "")    // elimina las tildes
    .replace(/#/g, "Ñ");                // devolvemos la Ñ
}

function textoAMorse(texto) {
  const limpio = limpiarTexto(texto);

  return limpio
    .split(/\s+/)                       // separa en palabras
    .filter((palabra) => palabra.length > 0)
    .map((palabra) =>
      palabra
        .split("")                      // separa en caracteres
        .map((caracter) => MORSE[caracter])
        .filter(Boolean)                // descarta lo que no está en el diccionario
        .join(" ")                      // espacio entre letras
    )
    .filter((palabra) => palabra.length > 0)
    .join(" / ");                       // " / " entre palabras
}

// ---------- TRADUCCIÓN: MORSE → TEXTO ----------

// Acepta variantes de símbolos y descarta todo lo que no sea Morse
function limpiarMorse(texto) {
  return texto
    .replace(/[•·]/g, ".")              // puntos "bonitos" → .
    .replace(/[—–−_]/g, "-")            // rayas "bonitas" → -
    .replace(/[^.\-\/\s]/g, "");        // quita cualquier otro carácter
}

// Convierte ".... --- .-.. .- / -- ..-" en "HOLA MU"
function morseATexto(morse) {
  return limpiarMorse(morse)
    .split(/\s*\/\s*|\s{3,}/)           // palabras: "/" o 3+ espacios
    .map((palabra) =>
      palabra
        .trim()
        .split(/\s+/)                   // letras: espacios
        .filter(Boolean)
        .map((codigo) => INVERSO[codigo] || "?")
        .join("")
    )
    .filter((palabra) => palabra.length > 0)
    .join(" ");
}

// Deja el Morse escrito listo para sonar
function morseParaReproducir(texto) {
  return limpiarMorse(texto)
    .replace(/\s{3,}/g, " / ")
    .replace(/\s+/g, " ")
    .trim();
}

// ---------- AUDIO (Web Audio API) ----------
let audioCtx = null;
let oscilador = null;
let ganancia = null;

// Crea el sistema de audio (debe hacerse tras un clic del usuario)
function prepararAudio() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();

    oscilador = audioCtx.createOscillator();
    oscilador.type = "sine";
    oscilador.frequency.value = Number(sliderTono.value);

    ganancia = audioCtx.createGain();
    ganancia.gain.value = 0; // empieza en silencio

    oscilador.connect(ganancia);
    ganancia.connect(audioCtx.destination);
    oscilador.start();
  }

  if (audioCtx.state === "suspended") {
    audioCtx.resume();
  }
}

// Enciende o apaga el pitido (con una transición mínima para evitar "clics")
function sonar(encendido) {
  if (!audioCtx || !chkSonido.checked) return;
  const volumen = encendido ? 0.4 : 0;
  ganancia.gain.setTargetAtTime(volumen, audioCtx.currentTime, 0.005);
}

// ---------- REPRODUCCIÓN DEL MORSE ----------
const cola = [];            // frases pendientes por sonar
let reproduciendo = false;  // ¿hay algo sonando?
let generacion = 0;         // sirve para poder cancelar una reproducción

function dormir(ms) {
  return new Promise((resolver) => setTimeout(resolver, ms));
}

// Duración de un "punto" en ms según la velocidad (1200 / palabras por minuto)
function unidad() {
  return 1200 / Number(sliderVelocidad.value);
}

function etiquetaTransmitir(activo) {
  btnTransmitir.textContent = activo ? t("parar") : t("transmitir");
}

// Pitido + luz durante "ms" milisegundos
async function emitirTono(ms, miGen) {
  luz.classList.add("encendida");
  sonar(true);
  await dormir(ms);
  if (miGen === generacion) {
    luz.classList.remove("encendida");
    sonar(false);
  }
}

// Reproduce una cadena como ".... --- .-.. .- / -- ..-"
async function reproducirMorse(morse, miGen) {
  for (const simbolo of morse) {
    if (miGen !== generacion) return; // alguien pulsó Parar
    const u = unidad();

    if (simbolo === ".") {
      await emitirTono(u, miGen);       // punto = 1 unidad
      await dormir(u);                  // pausa entre símbolos = 1 unidad
    } else if (simbolo === "-") {
      await emitirTono(u * 3, miGen);   // raya = 3 unidades
      await dormir(u);
    } else if (simbolo === " " || simbolo === "/") {
      await dormir(u * 2);              // completa pausa entre letras (3) y palabras (7)
    }
  }
}

async function reproducirCola() {
  if (reproduciendo) return;
  reproduciendo = true;
  etiquetaTransmitir(true);
  const miGen = generacion;

  while (cola.length > 0 && miGen === generacion) {
    const morse = cola.shift();
    await reproducirMorse(morse, miGen);
    if (miGen !== generacion) break;
    await dormir(unidad() * 7); // pausa entre frases
  }

  if (miGen === generacion) {
    reproduciendo = false;
    etiquetaTransmitir(false);
  }
}

// Corta todo lo que esté sonando y vacía la cola
function detenerReproduccion() {
  generacion++;
  cola.length = 0;
  reproduciendo = false;
  luz.classList.remove("encendida");
  sonar(false);
  etiquetaTransmitir(false);
}

// Pitido corto para probar el tono cuando mueves el control
async function probarTono() {
  if (reproduciendo) return;
  sonar(true);
  await dormir(200);
  if (!reproduciendo) sonar(false);
}

// Suena un punto (1) o una raya (3) al pulsar el teclado Morse
async function tocarSimbolo(unidades) {
  prepararAudio();
  if (reproduciendo) return;
  await emitirTono(unidad() * unidades, generacion);
}

// ---------- MODO: TEXTO → MORSE  /  MORSE → TEXTO ----------

function etiquetaCopiar() {
  return modo === "texto" ? t("copiarMorse") : t("copiarTexto");
}

// Actualiza la traducción y muestra u oculta botones según haya contenido
function actualizarVista() {
  const esTexto = modo === "texto";

  resultado.textContent = esTexto
    ? textoAMorse(mensaje.value)
    : morseATexto(mensaje.value);

  const hayEntrada = mensaje.value.trim().length > 0;
  btnBorrar.hidden = !hayEntrada; // la basura solo aparece si hay algo escrito

  const morseParaSonar = esTexto
    ? resultado.textContent
    : morseParaReproducir(mensaje.value);

  btnTransmitir.disabled = morseParaSonar.length === 0;
  btnCopiar.disabled = resultado.textContent.length === 0;
}

// Cambia textos y paneles según la dirección elegida
function aplicarModo() {
  const esTexto = modo === "texto";

  chipOrigen.textContent = esTexto ? t("chipTexto") : t("chipMorse");
  chipDestino.textContent = esTexto ? t("chipMorse") : t("chipTexto");

  tituloEntrada.textContent = esTexto ? t("tuMensaje") : t("tuMorse");
  tituloSalida.textContent = esTexto ? t("codigoMorse") : t("textoTraducido");

  mensaje.placeholder = esTexto ? t("placeholderTexto") : t("placeholderMorse");
  mensaje.setAttribute("aria-label", esTexto ? t("tuMensaje") : t("tuMorse"));
  mensaje.classList.toggle("entrada-morse", !esTexto);

  resultado.classList.toggle("morse", esTexto);
  resultado.dataset.vacio = esTexto ? t("vacioMorse") : t("vacioTexto");

  panelVoz.hidden = !esTexto;
  panelTeclado.hidden = esTexto;
  ayudaEntrada.hidden = esTexto;

  btnCopiar.textContent = etiquetaCopiar();

  actualizarVista();
}

// ⇄ Invertir: lo que era resultado pasa a ser la entrada
btnInvertir.addEventListener("click", () => {
  detenerReproduccion();
  if (detenerDictado) detenerDictado();

  const nuevaEntrada = resultado.textContent;
  modo = modo === "texto" ? "morse" : "texto";
  mensaje.value = nuevaEntrada;

  btnInvertir.classList.toggle("girado");
  aplicarModo();
});

// ---------- CUADRO DE MENSAJE ----------

// Texto provisional (lo que el micrófono va entendiendo) mostrado dentro del cuadro
let interinoMostrado = "";

function quitarInterino() {
  if (interinoMostrado && mensaje.value.endsWith(interinoMostrado)) {
    mensaje.value = mensaje.value.slice(0, mensaje.value.length - interinoMostrado.length);
  }
  interinoMostrado = "";
}

function mostrarInterino(texto) {
  const limpio = texto.trim();
  if (!limpio) return;
  const separador = mensaje.value.trim() ? " " : "";
  interinoMostrado = separador + limpio;
  mensaje.value += interinoMostrado;
}

// Agrega una frase confirmada al final del mensaje
function agregarTexto(texto) {
  const limpio = texto.trim();
  if (!limpio) return;

  mensaje.value = mensaje.value.trim()
    ? mensaje.value.trimEnd() + " " + limpio
    : limpio;
}

// Escribir a mano también actualiza la traducción
mensaje.addEventListener("input", actualizarVista);

// 🗑️ Borrar todo
btnBorrar.addEventListener("click", () => {
  detenerReproduccion();
  interinoMostrado = "";
  mensaje.value = "";
  actualizarVista();
  if (modo === "texto") mensaje.focus();
});

// ---------- TECLADO MORSE ----------
function insertarEnMensaje(texto) {
  const inicio = mensaje.selectionStart;
  const fin = mensaje.selectionEnd;
  mensaje.setRangeText(texto, inicio, fin, "end");
  actualizarVista();
}

function retrocederEnMensaje() {
  const inicio = mensaje.selectionStart;
  const fin = mensaje.selectionEnd;

  if (inicio !== fin) {
    mensaje.setRangeText("", inicio, fin, "end");
  } else if (inicio > 0) {
    mensaje.setRangeText("", inicio - 1, inicio, "end");
  }
  actualizarVista();
}

btnPunto.addEventListener("click", () => {
  insertarEnMensaje(".");
  tocarSimbolo(1);
});

btnRaya.addEventListener("click", () => {
  insertarEnMensaje("-");
  tocarSimbolo(3);
});

btnLetra.addEventListener("click", () => insertarEnMensaje(" "));
btnPalabra.addEventListener("click", () => insertarEnMensaje(" / "));
btnRetroceso.addEventListener("click", retrocederEnMensaje);

// ---------- TRANSMITIR Y COPIAR ----------

// ▶ Transmitir / ⏹ Parar
btnTransmitir.addEventListener("click", () => {
  prepararAudio();

  if (reproduciendo) {
    detenerReproduccion();
    return;
  }

  const morse = modo === "texto"
    ? textoAMorse(mensaje.value)
    : morseParaReproducir(mensaje.value);

  if (!morse) return;
  cola.push(morse);
  reproducirCola();
});

// 📋 Copiar el resultado
btnCopiar.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(resultado.textContent);
    btnCopiar.textContent = t("copiado");
  } catch (error) {
    btnCopiar.textContent = t("noCopio");
  }
  setTimeout(() => {
    btnCopiar.textContent = etiquetaCopiar();
  }, 1500);
});

// ---------- AJUSTES ----------
sliderVelocidad.addEventListener("input", () => {
  valorVelocidad.textContent = sliderVelocidad.value;
});

sliderTono.addEventListener("input", () => {
  valorTono.textContent = sliderTono.value;
  if (oscilador) {
    oscilador.frequency.setTargetAtTime(
      Number(sliderTono.value),
      audioCtx.currentTime,
      0.01
    );
  }
});

// Al soltar el control de tono, suena un pitido corto de prueba
sliderTono.addEventListener("change", () => {
  prepararAudio();
  probarTono();
});

// ---------- DICCIONARIO ----------
function tocarCaracter(caracter) {
  prepararAudio();
  detenerReproduccion();
  cola.push(MORSE[caracter]);
  reproducirCola();
}

function llenarDiccionario(contenedor, caracteres) {
  caracteres.forEach((caracter) => {
    const ficha = document.createElement("button");
    ficha.type = "button";
    ficha.className = "ficha";
    ficha.innerHTML =
      '<span class="ficha-letra">' + caracter + "</span>" +
      '<span class="ficha-codigo">' + MORSE[caracter] + "</span>";
    ficha.addEventListener("click", () => tocarCaracter(caracter));
    contenedor.appendChild(ficha);
  });
}

function crearDiccionario() {
  llenarDiccionario(
    document.getElementById("dic-letras"),
    "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ".split("")
  );
  llenarDiccionario(
    document.getElementById("dic-numeros"),
    "0123456789".split("")
  );
}

// ---------- RECONOCIMIENTO DE VOZ ----------
const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;

function iniciarApp() {
  const reconocimiento = new SpeechRecognition();
  reconocimiento.lang = selectIdioma.value;
  reconocimiento.continuous = true;     // sigue escuchando sin cortarse
  reconocimiento.interimResults = true; // muestra texto mientras hablas

  let quiereEscuchar = false; // lo que decide el usuario con el botón

  // Lo usa el botón ⇄ para apagar el micrófono al cambiar de modo
  detenerDictado = () => {
    if (quiereEscuchar) {
      quiereEscuchar = false;
      reconocimiento.stop();
    }
  };

  // Cambiar de idioma (si está escuchando, se reinicia solo con el nuevo idioma)
  selectIdioma.addEventListener("change", () => {
    reconocimiento.lang = selectIdioma.value;
    if (quiereEscuchar) {
      reconocimiento.stop();
    }
  });

  // Clic en el botón: iniciar o detener
  boton.addEventListener("click", () => {
    if (quiereEscuchar) {
      quiereEscuchar = false;
      reconocimiento.stop();
    } else {
      prepararAudio(); // el audio solo se puede crear tras un clic
      quiereEscuchar = true;
      reconocimiento.start();
    }
  });

  reconocimiento.onstart = () => {
    estadoMicro = "escuchando";
    refrescarMicro();
  };

  // Cuando llega texto reconocido: aparece dentro del cuadro de mensaje
  reconocimiento.onresult = (evento) => {
    let finales = "";
    let interino = "";

    for (let i = evento.resultIndex; i < evento.results.length; i++) {
      const transcripcion = evento.results[i][0].transcript;

      if (evento.results[i].isFinal) {
        finales += transcripcion + " ";
      } else {
        interino += transcripcion;
      }
    }

    quitarInterino(); // quita lo provisional anterior antes de poner lo nuevo

    if (finales.trim()) {
      agregarTexto(finales);

      // La frase confirmada también suena en Morse
      const morseFrase = textoAMorse(finales);
      if (morseFrase) {
        cola.push(morseFrase);
        reproducirCola();
      }
    }

    if (interino.trim()) {
      mostrarInterino(interino);
    }

    actualizarVista();
  };

  reconocimiento.onend = () => {
    interinoMostrado = ""; // lo que haya quedado se conserva como texto normal

    if (quiereEscuchar) {
      // Chrome a veces corta solo tras un silencio: lo reiniciamos
      reconocimiento.start();
    } else {
      // Si hubo un error, se conserva su mensaje; si no, queda apagado
      if (estadoMicro === "escuchando") estadoMicro = "apagado";
      refrescarMicro();
    }
  };

  reconocimiento.onerror = (evento) => {
    console.error("Error de reconocimiento:", evento.error);

    if (evento.error === "not-allowed" || evento.error === "service-not-allowed") {
      estadoMicro = "permiso";
      quiereEscuchar = false;
    } else if (evento.error === "audio-capture") {
      estadoMicro = "sinmicro";
      quiereEscuchar = false;
    } else if (evento.error === "network") {
      estadoMicro = "red";
      quiereEscuchar = false;
    }
    refrescarMicro();
    // "no-speech" (silencio) lo ignoramos: onend lo reinicia solo
  };
}

// ---------- ARRANQUE ----------
crearDiccionario();

if (!SpeechRecognition) {
  // Sin dictado, igual se puede escribir
  estadoMicro = "sinsoporte";
  boton.disabled = true;
  selectIdioma.disabled = true;
} else {
  iniciarApp();
}

// Aplica el idioma guardado (o español) y pinta toda la página
aplicarIdioma(idiomaInicial(), false);